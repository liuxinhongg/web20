// 登陆页面
//注册
$(".username").focus(function () {
    $(".kuang-user").fadeIn();
})
$(".username").blur(function () {
    $(".kuang-user").fadeOut();
    var text1 = $(".username").val();
    var reg1 = text1.match(/^[a-zA-Z0-9_-]{4,16}$/);
    if (!reg1) {
        $(this).val("");
        $(this).parent().find(".defult").show();
        $(this).parent().find(".success").hide();
    } else {
        $(this).parent().find(".success").show();
        $(this).parent().find(".defult").hide();
    }
})
$(".password").focus(function () {
    $(".kuang-pass").fadeIn();
})
$(".password").blur(function () {
    $(".kuang-pass").fadeOut();
    var text1 = $(".password").val();
    //以字母开头，长度在6~18之间，只能包含字母、数字和下划线
    var reg1 = text1.match(/^[a-zA-Z]\w{5,17}$/);
    if (!reg1) {
        $(this).val("");
        $(this).parent().find(".defult").show();
        $(this).parent().find(".success").hide();
    } else {
        $(this).parent().find(".success").show();
        $(this).parent().find(".defult").hide();
    }
})
$(".phonenumber").blur(function () {
    var text1 = $(".phonenumber").val();
    var reg1 = text1.match(/^1[^120]{1}[0-9]{9}$/);
    if (!reg1) {
        $(this).val("");
        $(this).parent().find(".defult").show();
        $(this).parent().find(".success").hide();
    } else {
        $(this).parent().find(".success").show();
        $(this).parent().find(".defult").hide();
    }
})
$(".email").blur(function () {
    var text1 = $(".email").val();
    var reg1 = text1.match(/^[A-Za-z0-9]+@[a-z0-9]+\.[com|cn]+$/);
    if (!reg1) {
        $(this).val("");
        $(this).parent().find(".defult").show();
        $(this).parent().find(".success").hide();
    } else {
        $(this).parent().find(".success").show();
        $(this).parent().find(".defult").hide();
    }
})

//登录跳转注册
$(".log-reg").click(function () {
    location.href = "settlement-reg.html";
})
//注册跳转登录
$(".reg-log").click(function () {
    location.href = "settlement-log.html";
})
//注册
$(".reg-button").click(function () {
    $.ajax({
        url: "http://localhost:3000/settlement/userReg",
        type: "post",
        data: {
            username: $("#aa").val(),
            password: $("#bb").val(),
            email: $("#cc").val(),
            phone: $("#dd").val(),
        },
        success: function (res) {
            console.log(res);
            alert("注册成功，请登录!!!");
            location.href = "settlement-log.html";
        }
    })
})
//登录
$(".login-button").click(function () {
    $.ajax({
        url: "http://localhost:3000/settlement/userLog",
        type: "get",
        data: {
            username: $("#aa").val(),
            password: $("#bb").val(),
        },
        success: function (res) {
                location.href = "settlement-index.html";
        }
    })
})

//首页添加
$("#add-plan").click(function () {
    location.href = "zongplan.html";
})

//首页查询
$(".add-search").click(function () {
    var id = $("#searchID").val();
    $.ajax({
        url: "http://localhost:3000/settlement/masterSearchID",
        type: "get",
        data: {
            id: $("#searchID").val(),
        },
        success: function (res) {
            // console.log(res.info);
            $(".start-data").children().remove();
            $(".start-data").append(
                `                
                    <div class="have-data">
                        <div class="proj">
                            <span>总计划名称:</span>
                            <span>${res.info.planname}</span>
                        </div>
                        <div class="proj">
                            <span>提交人:</span>
                            <span>${res.info.cmtld}</span>
                        </div>
                        <div class="proj">
                            <span>项目ID:</span>
                            <span>${res.info.id}</span>
                        </div>
                        <div class="proj">
                            <span>审批人:</span>
                            <span>${res.info.leadernext}</span>
                        </div>
                    </div>
                `
            )
        }
    })
})

//物资计划提交
$("#set-tijiao").click(function () {
    $.ajax({
        url: "http://localhost:3000/settlement/insert",
        type: "post",
        data: {
            id: $("#id").val(),
            prld: $("#aa").val(),
            ctid: $("#bb").val()
        },
        success: function (res) {
            if (res.code === 1) {
                alert("插入成功!!!");
                location.href = "settlement-index.html";
            }
        }
    })
})