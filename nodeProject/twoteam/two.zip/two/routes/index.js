var express = require('express');
var db = require("../db");
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});
router.post("/zhuce", function (req, res, next) {
  console.log(req.body);
  var user = req.body.username;
  var pass = req.body.password;
  var email = req.body.email;
  var phone = req.body.phone;
  if (user == "" || user == undefined) {
    res.send({ code: -1, message: "用户名不能为空" });
  } else {
    db.query("select * from user where username = ?", [user], function (result) {
      if (result.length) {
        res.send({ message: "该用户已注册", code: 1 });
      } else {
        db.query("insert into user (username,password,email,phone) values (?,?,?,?)", [user, pass, email, phone], function (result) {
          res.send({ code: 0, message: '注册成功~' })
        })
      }
    })
  } 
})

//登录
router.post("/denglu", function (req, res, next) {
  console.log(req.body);
    var user = req.body.username;
    var pass = req.body.password;
    if (user == "" || user == undefined) {
      res.send({ code: -1, message: "用户名不能为空" });
    } else {
      db.query("select * from user where username = ?", [user], function (result) {
      console.log(result);
        if (result.length) {
          if (pass === result[0].password) {
            console.log(result);
            res.send({ code: 1, message: "登录成功!!" });
          } else {
            res.send({ code: -1, message: "密码错误!!" });
          }
        } else {
          res.send({ code: -2, message: "用户名不存在!!" });
        }
      })
  
    }
  })
//查询
router.get("/denglu1", function (req, res, next) {
  var user = req.query.username;
  if (user == "" || user == undefined) {
    res.send({ code: -1, message: "用户名不能为空" });
  }
  db.query("select id,username,email,phone from user where username = ?",[user],function(result) {
    if (result.length) {
      res.send({ data: result[0], code: "查询成功" });
    } else {
      res.send({ data:'用户不存在，请输入正确的用户名', code: 1 });
    }
  })
})
//修改
router.get("/xiugai", function(req, res, nest){
  var id = 5;
  var user = req.query.username;
  var pass = req.query.password;
  var email = req.query.email;
  var phone = req.query.phone;
  if (user ==""||user==undefined) {
    res.send({code: -1,message:"用户名不能为空"});
  }
  db.query("select * from user where id = ?", [id], function (result) {
    if (result.length) {
      db.query("update user set username = ?,password = ?,email = ?,phone = ? where id = ?", [user, pass, email, phone, id], function (result) {
        res.send({ code: 0, message: '修改成功' });
      })
    } else {
      res.send({message: '用户不存在，请输入正确的用户名', code: 1 });
    }
  })
})
//加密


module.exports = router;
