var express = require('express');
var router = express.Router();
var db = require("../htdb.js");
var cbfile = require("../cbfile/cb.js");
var a_needplan = require("../cbfile/needplanfn");

router.post("/zhuce",cbfile.UserRegister)
router.post("/denglu", cbfile.userLogin)


//合同管理
router.post("/clzhuce",cbfile.Userclzhuce)
router.get("/clchaxun",cbfile.Userclchaxun)
router.get("/clxiugai",cbfile.Userclxiugai)
router.get("/clchaxunID",cbfile.UserclchaxunID)

//wjf
router.post("/zongplan",cbfile.zongplan)
router.post("/search",cbfile.search)
router.post("/zonggai",cbfile.zonggai)

router.post('/a_needplan',a_needplan.a_zengjia);
router.post('/a_xuigai',a_needplan.a_xiugai);
router.post('/a_chaxun',a_needplan.a_chaxun)


//删除
router.post('/delete1',cbfile.delete1)
router.post('/delete3',cbfile.delete3)


module.exports = router;
