var express = require('express');
var router = express.Router();
let db = require("../config/htdb.js");

var cbfile = require("../cbfile/settlement-cb.js");


//注册
router.post("/userReg", cbfile.userReg);
//登录
router.get("/userLog", cbfile.userLog);

//

//插入
router.post("/insert", cbfile.userSearch);
//查询
router.get("/read", cbfile.userRead);
// //修改
router.get("/update", cbfile.userUpdate);
// //删除
router.get("/delete", cbfile.userDelete);

//总计划查找ID
router.get("/masterSearchID", cbfile.masterSearchID);



module.exports = router;
