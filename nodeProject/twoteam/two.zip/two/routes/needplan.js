var express = require('express');
var router = express.Router();
var db = require("../htdb.js");
var a_needplan = require("../cbfile/needplanfn.js")

router.get('/', function (req, res, next) {
    res.send('respond with a resource');
});
router.post('/a_needplan',a_needplan.a_zengjia);
router.post('/a_chaxunID', a_needplan.a_chaxunID);
router.post('/a_xiugai', a_needplan.a_xiugai);
router.post('/a_delete', a_needplan.a_delete);

module.exports = router