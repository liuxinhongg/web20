let sqlconfig = require("../config/sql.js")
let db = require("../config/htdb.js");
// 登录生成token
const jswt = require("jsonwebtoken")
const { md5 } = require("../config/methods.js");
const { PWD, PRIVATE_KEY, EXPIRESD } = require("../config/constant.js")
class Bfile {
	//结算
	Userclzhuce(req, res, next) {
		var userid = req.body.userid;
		var ctname = req.body.ctname;
		var cttype = req.body.cttype;
		var prld = req.body.prld;
		var ctsum = req.body.ctsum;
		var paymode = req.body.paymode;
		var cdDate = req.body.cdDate;
		var prjld = req.body.prjld;
		var prePay = req.body.prePay;
		var deposit = req.body.deposit;
		var ctexecMan = req.body.ctexecMan;
		var leaderNext = req.body.leaderNext;
		var mld = req.body.mld;
		var ctdNum = req.body.ctdNum;
		var ctdMoney = req.body.ctdMoney;
		var ctdState = req.body.ctdState;
		if ((userid == "" || userid == undefined) && (ctname == "" || ctname == undefined)) {
			res.send({
				code: -1,
				message: "申请人不能为空"
			})
		} else {
			db.query(sqlconfig.userSearch1, [userid], function (result) {
				if (result.length) {
					res.send({
						message: "申请人已存在",
						code: 1
					})
				} else {
					db.query(sqlconfig.userInsert1, [userid, ctname, cttype, prld, ctsum, paymode, cdDate, prjld, prePay, deposit, ctexecMan, leaderNext, mld, ctdNum, ctdMoney, ctdState],
						function (result) {
							res.send({
								code: 0,
								message: '添加成功~'
							})
						})
				}
			})
		}
	}
	//查询
	Userclchaxun(req, res, next) {
		var userid = req.query.userid;
		if (userid == "" || userid == undefined) {
			res.send({ code: -1, message: "查询申请人不能为空" });
		} else {
			db.query(sqlconfig.userSearch2, [userid], function (result) {
				console.log(2)
				if (result.length) {
					res.send({ data: result[0], code: "查询成功" });
				} else {
					res.send({ data: '申请人不存在，请输入正确的用户名', code: 1 });
				}
			})
		}
	}
	//ID查询
	UserclchaxunID(req, res, next) {
		var id = req.query.id;
		db.query(sqlconfig.userSearch3, [id], function (result) {
			res.send({ data: result[0], code: "查询成功" });
		})
	}
	//修改
	Userclxiugai(req, res, nest) {
		var id = req.query.id;
		var userid = req.query.userid;
		var ctname = req.query.ctname;
		var cttype = req.query.cttype;
		var prld = req.query.prld;
		var ctsum = req.query.ctsum;
		var paymode = req.query.paymode;
		var cdDate = req.query.cdDate;
		var prjld = req.query.prjld;
		var prePay = req.query.prePay;
		var deposit = req.query.deposit;
		var ctexecMan = req.query.ctexecMan;
		var leaderNext = req.query.leaderNext;
		var mld = req.query.mld;
		var ctdNum = req.query.ctdNum;
		var ctdMoney = req.query.ctdMoney;
		var ctdState = req.query.ctdState;
		if (userid == "" || ctname == "" || cttype == "" || prld == "" || ctsum == "" || paymode == "" || cdDate == "" || prjld == "" || prePay == "" || deposit == "" || ctexecMan == "" || leaderNext == "" || mld == "" || ctdNum == "" || ctdMoney == "" || ctdState == "") {
			res.send({ code: -1, message: "修改申请人不能为空" });
		} else {
			db.query(sqlconfig.userSearch4, [userid, ctname, cttype, prld, ctsum, paymode, cdDate, prjld, prePay, deposit, ctexecMan, leaderNext, mld, ctdNum, ctdMoney, ctdState, id], function (result) {
				res.send({ code: 0, message: '修改成功' });
			})
		}
	}





	UserRegister(req, res, next) {
		console.log(req.body)
		var user = req.body.username;
		var pass = req.body.password;
		var email = req.body.email;
		var phone = req.body.phone;
		if ((user == "" || user == undefined) && (pass == "" || pass == undefined)) {
			res.send({
				code: -1,
				message: "用户名不能为空"
			})
		} else {
			db.query(sqlconfig.userSearch, [user], function (result) {
				if (result.length) {
					res.send({
						message: "该用户已注册",
						code: 1
					})
				} else {
					pass = md5(`${pass}${PWD}`);
					db.query(sqlconfig.userInsert, [user, pass, email, phone],
						function (result) {
							res.send({
								code: 0,
								message: '注册成功~'
							})
						})
				}
			})
		}
	}
	userLogin(req, res, next) {
		var user = req.body.username;
		var pass = req.body.password;
		if (!user && !pass) {
			res.send({
				code: -1,
				message: "用户名或密码不能为空"
			})
		} else {
			db.query(sqlconfig.userSearch, [user], function (result) {
				if (result.length) {
					pass = md5(`${pass}${PWD}`);
					// 首先要确保用户存在,这样我们就可以生成一个token,
					if (result[0].password === pass) {
						// 生成token jswt.sign({user},密钥，过期时间)
						let token = jswt.sign({
							user
						}, PRIVATE_KEY, {
							expiresIn: EXPIRESD
						});
						res.send({
							code: 0,
							message: "登录成功",
							token: token
						})
					} else {
						res.send({
							code: 1,
							message: "密码错误"
						})
					}
				} else {
					res.send({
						code: 2,
						message: "用户名不存在，请先注册"
					})
				}
			})
		}
	}

	zongplan(req, res, next) {
		var planname = req.body.planname;
		var cmtld = req.body.cmtld;
		var id = req.body.id;
		var leadernext = req.body.leadernext;
		var cdate = req.body.cdate;
		var mname = req.body.mname;
		var useloc = req.body.useloc;
		var mnum = req.body.mnum;
		if ((planname == "" || planname == undefined) && (cmtld == "" || cmtld == undefined) && (id == "" || id == undefined) && (leadernext == "" || leadernext == undefined) && (cdate == "" || cdate == undefined) && (mname == "" || mname == undefined) && (useloc == "" || useloc == undefined) && (mnum == "" || mnum == undefined)) {
			res.send({
				code: -1,
				message: "项目错误"
			})
		}
		else {
			db.query(sqlconfig.zongserch, [id], function (result) {
				if (result.length) {
					res.send({
						code: 1,
						message: "项目已存在"
					})
				}
				else {
					db.query(sqlconfig.zongplan, [planname, cmtld, id, leadernext, cdate, mname, useloc, mnum],
						function (result) {
							res.send({
								code: 0,
								message: '注册成功~',
							})
						})
				}
			})
		}
	}
	search(req, res, next) {
		var id = req.body.id;
		// console.log(id);
		db.query(sqlconfig.find, [id],
			function (result) {
				console.log(result)
				res.send({
					result
				})
			})

	}
	zonggai(req, res, next) {
		var id = req.body.id;
		var planname = req.body.planname;
		var cmtld = req.body.cmtld;
		var leadernext = req.body.leadernext;
		var cdate = req.body.cdate;
		var mname = req.body.mname;
		var useloc = req.body.useloc;
		var mnum = req.body.mnum;
		if ((planname == "" || planname == undefined) && (cmtld == "" || cmtld == undefined) && (leadernext == "" || leadernext == undefined) && (cdate == "" || cdate == undefined) && (mname == "" || mname == undefined) && (useloc == "" || useloc == undefined) && (mnum == "" || mnum == undefined)) {
			res.send({
				code: -1,
				message: "不能为空"
			})
		}
		else {
			console.log(111);
			db.query(sqlconfig.zonggai, [planname, cmtld, leadernext, cdate, mname, useloc, mnum, id],
				function (result) {
					res.send({
						code: 0,
						message: '修改成功~',
					})
				})
		}
	}


	//删除
    delete1(req, res, next) {
        var id = req.body.id;
        db.query(sqlconfig.userDelete1, [id], function (result) {
            res.send({result});
        })
    }
    delete3(req, res, next) {
        var id = req.body.id;
        db.query(sqlconfig.userDelete3, [id], function (result) {
            res.send({result});
        })
    }

}
module.exports = new Bfile()