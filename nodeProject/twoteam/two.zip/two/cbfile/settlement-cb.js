let sqlconfig = require("../config/set-sql.js")
let db = require("../config/htdb.js");
// 登录生成token
const jswt = require("jsonwebtoken")
// const { md5 } = require("../config/method.js");
// const { PWD, PRIVATE_KEY, EXPIRESD } = require("../config/constant.js");

class callBack {
  //注册
  userReg(req, res, next) {
    var user = req.body.username;
    var pass = req.body.password;
    var email = req.body.email;
    var phone = req.body.phone;
    if (user == "" || user == undefined) {
      res.send({ code: -1, message: "用户名不能为空" });
    } else {
      db.query(sqlconfig.userRegSearch, [user], function (result) {
        if (result.length) {
          res.send({ code: -2, message: "该用户名已存在" });
        } else {
          db.query(sqlconfig.userReg, [user, pass, email, phone], function (result) {
            res.send({ code: 1, message: "注册成功!!" });
          })
        }
      })
    }
  }
  //登录
  userLog(req, res, next) {
    var user = req.query.username;
    var pass = req.query.password;
    if (user == "" || user == undefined) {
      res.send({ code: -1, message: "用户名不能为空" });
    } else {
      db.query(sqlconfig.userRegSearch, [user], function (result) {
        if (result.length) {
          if (pass === result[0].password) {
            res.send({ code: 1, message: "登录成功!!" });
          } else {
            res.send({ code: -1, message: "密码错误!!" });
          }
        } else {
          res.send({ code: -2, message: "用户名不存在!!" });
        }
      })
    }
  }

  //插入
  userSearch(req, res, next) {
    var id = req.body.id;
    var prld = req.body.prld;
    var ctid = req.body.ctid;
    if (ctid == "" || prld == "") {
      res.send({ code: -1, message: "输入不能为空" });
    } else {
      db.query(sqlconfig.userSearch, [ctid], function (result) {
        if (result.length) {
          res.send({ message: "该合同已插入", code: 0 });
        } else {
          // pass = md5(`${pass}${PWD}`);
          db.query(sqlconfig.userInsert, [id, prld, ctid], function (result) {
            res.send({ code: 1, message: '插入成功~' })
          })
        }
      })
    }
  }
  //查询
  userRead(req, res, next) {
    var id = req.query.id;
    if (id == "" || id == undefined) {
      res.send({ code: -1, message: "项目ID不能为空" });
    } else {
      db.query(sqlconfig.userSearchID, [id], function (result) {
        if (result.length) {
          res.send({ code: 1, message: "查询成功!!", info: result[0] });
        } else {
          res.send({ code: -2, message: "该合同不存在!!" });
        }
      })
    }
  }

  //修改
  userUpdate(req, res, next) {
    var id = req.query.id;
    var ctid = req.query.ctid;
    var prld = req.query.prld;
    db.query(sqlconfig.userUpdate, [prld, ctid, id], function (result) {
      res.send({ code: 1, message: "修改成功0.0" });
    })
  }
  //删除
  userDelete(req, res, next) {
    var id = req.query.id;
    db.query(sqlconfig.userDelete, [id], function (result) {
      res.send({ code: 1, message: "删除成功!!" });
    })
  }

  //总计划ID查询
  masterSearchID(req, res, next) {
    var id = req.query.id;
    if (id == "" || id == undefined) {
      res.send({ code: -1, message: "项目ID不能为空" });
      alert("项目ID不能为空");
    } else {
      db.query(sqlconfig.masterSearchID, [id], function (result) {
        if (result.length) {
          res.send({ code: 1, message: "查询成功!!", info: result[0] });
        } else {
          res.send({ code: -2, message: "该项目不存在!!" });
          alert("该项目不存在!!");
        }
      })
    }
  }
}

module.exports = new callBack;