var db = require("../config/htdb.js");
var a_sql = require("../config/a_sql.js");
class Needplan {
    a_zengjia(req, res, next) {
        var a_mrName = req.body.a_mrName;
        var a_prjId = req.body.a_prjId;
        var a_cmtMan = req.body.a_cmtMan;
        var a_execMan = req.body.a_execMan;
        var a_cmtDate = req.body.a_cmtDate;
        var a_comeDate = req.body.a_comeDate;
        var a_mmid = req.body.a_mmid;
        var a_useloc = req.body.a_useloc;
        var a_mnum = req.body.a_mnum;
        var a_mprice = req.body.a_mprice;
        var a_ifover = req.body.a_ifover;
        var a_msum = req.body.a_msum;
        var a_provState = req.body.a_provState;
        if ((a_mrName == "" || a_mrName == undefined) && (a_prjId == "" || a_prjId == undefined) && (a_cmtMan == "" || a_cmtMan == undefined) && (a_execMan == "" || a_execMan == undefined) && (a_cmtDate == "" || a_cmtDate == undefined) && (a_comeDate == "" || a_comeDate == undefined) && (a_mmid == "" || a_mmid == undefined) && (a_useloc == "" || a_useloc == undefined) && (a_mnum == "" || a_mnum == undefined) && (a_mprice == "" || a_mprice == undefined) && (a_ifover == "" || a_ifover == undefined) && (a_msum == "" || a_msum == undefined) && (a_provState == "" || a_provState == undefined)) {
            res.send({ code: -1, message: "不能为有空" })
        } else {
            db.query(a_sql.tianjia,[a_mrName,a_prjId,a_cmtMan,a_execMan,a_cmtDate,a_comeDate,a_mmid,a_useloc,a_mnum,a_mprice,a_ifover,a_msum,a_provState],function (result) {
                res.send({ code: 0, message: '录入成功',result: result})
                console.log(1);
            })
        }
    }
    a_xiugai(req, res, next) {
        var id = req.body.id;
        var a_mrName = req.body.a_name;
        var a_prjId = req.body.a_prj;
        var a_cmtMan = req.body.a_tijiaoname;
        var a_execMan = req.body.a_zhixing;
        var a_cmtDate = req.body.a_tijiaodate;
        var a_comeDate = req.body.a_daochang;
        var a_mmid = req.body.a_cailiao;
        var a_useloc = req.body.a_weizhi;
        var a_mnum = req.body.a_liang;
        var a_mprice = req.body.a_jiage;
        var a_ifover = req.body.a_chaoe;
        var a_msum = req.body.a_ssum;
        // var a_provState = req.body.a_provState;
        if ((a_mrName == "" || a_mrName == undefined) && (a_prjId == "" || a_prjId == undefined) && (a_cmtMan == "" || a_cmtMan == undefined) && (a_execMan == "" || a_execMan == undefined) && (a_cmtDate == "" || a_cmtDate == undefined) && (a_comeDate == "" || a_comeDate == undefined) && (a_mmid == "" || a_mmid == undefined) && (a_useloc == "" || a_useloc == undefined) && (a_mnum == "" || a_mnum == undefined) && (a_mprice == "" || a_mprice == undefined) && (a_ifover == "" || a_ifover == undefined) && (a_msum == "" || a_msum == undefined) && (a_provState == "" || a_provState == undefined)) {
            res.send({ code: -1, message: "不能为有空" })
        } else {
            db.query(a_sql.xuigai,[a_mrName,a_cmtMan,a_execMan,a_cmtDate,a_comeDate,a_mmid,a_useloc,a_mnum,a_mprice,a_ifover,a_msum, id],function (result) {
                res.send({ code: 0, message: '录入成功'});
            })
        }
    }
    a_chaxun(req, res, next) {
        var a_mrName = req.body.a_mrName;
        var a_prjId = req.body.a_prjId;
        var a_cmtMan = req.body.a_cmtMan;
        var a_execMan = req.body.a_execMan;
        var a_cmtDate = req.body.a_cmtDate;
        var a_comeDate = req.body.a_comeDate;
        var a_mmid = req.body.a_mmid;
        var a_useloc = req.body.a_useloc;
        var a_mnum = req.body.a_mnum;
        var a_mprice = req.body.a_mprice;
        var a_ifover = req.body.a_ifover;
        var a_msum = req.body.a_msum;
        var a_provState = req.body.a_provState;
        if ((a_mrName == "" || a_mrName == undefined) && (a_prjId == "" || a_prjId == undefined) && (a_cmtMan == "" || a_cmtMan == undefined) && (a_execMan == "" || a_execMan == undefined) && (a_cmtDate == "" || a_cmtDate == undefined) && (a_comeDate == "" || a_comeDate == undefined) && (a_mmid == "" || a_mmid == undefined) && (a_useloc == "" || a_useloc == undefined) && (a_mnum == "" || a_mnum == undefined) && (a_mprice == "" || a_mprice == undefined) && (a_ifover == "" || a_ifover == undefined) && (a_msum == "" || a_msum == undefined) && (a_provState == "" || a_provState == undefined)) {
            res.send({ code: -1, message: "不能为有空" })
        } else {
            db.query(a_sql.chaxun,[a_id],function (result) {
                res.send({ code: 0, message: '录入成功',result: result})
                console.log(1);
            })
        }
    }


    a_chaxunID(req, res, next) {
        var id = req.body.id;
        db.query(a_sql.chaxunID, [id], function (result) {
            console.log(result);
            res.send({result});
        })
    }

    a_delete(req, res, next) {
        var id = req.body.id;
        db.query(a_sql.userDelete2, [id], function (result) {
            res.send({result});
        })
    }
}
module.exports = new Needplan()