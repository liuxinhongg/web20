// let mysql = require("mysql");
// console.log(mysql);
// var connection = mysql.createConnection({
//     host:"localhost",
//     user:"root",
//     password:"root",
//     port:"3306",
//     database:"juzijiang",
// });
// connection.connect();
//新增数据
// var addsql = "insert into user(username,password,email,phone) values(?,?,?,?)";
// var addsqlparams = ["李子辰","123456","912400@qq.com","15641981651"]
// var addsqlparams2 = ["王继峰","123456","912400@qq.com","15641981651"]
// var addsqlparams3 = ["屈卓欣","123456","912400@qq.com","15641981651"]
// connection.query(addsql,addsqlparams3,function(err,result){
//     if(err) {
//         console.log(err.message);
//         return;
//     }
//     console.log(result);
// });
//删除
// var delsql = "delete from user where username = '李子辰'";
// connection.query(delsql,function(err,result) {
//     if(err) {
//         console.log(err.message);
//         return;
//     }
//     console.log(result);
// })
//修改
// var update = "update user set username = ? where id=?";

// var up = ["欣欣酱",4];
// connection.query(update,up,function(err,result){
//     if(err) {
//         console.log(err.message);
//         return;
//     }
//     console.log(result);
// })
//查询
// var searchSql = "select * from user";
// connection.query(searchSql,function(err,result){
// 	if(err){
// 		console.log(err.message);
// 		return
// 	}
// 	console.log(result)
// })
// connection.end();
//按条件查询
// var searchSql="select username,email,phone from user where id=?";
// var searchParams = [5];
// connection.query(searchSql,searchParams,function(err,result){
// 	if(err){
// 		console.log(err.message);
// 		return
// 	}
// 	console.log(result)
// })
// connection.end()





var mysql = require("mysql");
var pool = mysql.createPool({
    host:"localhost",
    user:"root",
    password:"root",
    port:"3306",
    database:"juzijiang",
});
exports.query=function(sql,arr,callback) {
    pool.getConnection(function(err,connection){
        if(err) {
            throw err;
            return
        }
        connection.query(sql,arr,function(error,result){
            connection.release();
            if(error) throw error;
            callback && callback(result)
        })
    })
}