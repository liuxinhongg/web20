module.exports={
	// 加密需要密钥，我们定义一个密钥
    PWD_SALT:'simple_code',
    PRIVATE_KEY:"focus",
    EXPIRESD:60*60*24
}