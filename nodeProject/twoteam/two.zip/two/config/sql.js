let sqlConfig = {
	userInsert: 'insert into user (username,password,email,phone) values (?,?,?,?)',
	userSearch: 'select * from user where username = ?',
	userInsert1: 'insert into contract (userid,ctname,cttype,prld,ctsum,paymode,cdDate,prjld,prePay,deposit,ctexecMan,leaderNext,mld,ctdNum,ctdMoney,ctdState) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
	userSearch1: 'select * from contract where userid = ?',
	userSearch2: 'select ID,userid,ctname,cttype,prld,ctsum,paymode,cdDate,prjld,prePay,deposit,ctexecMan,leaderNext,mld,ctdNum,ctdMoney,ctdState from contract where userid = ?',
	userSearch3: 'select * from contract where prjld = ?',
	userSearch4: 'update contract set userid = ?,ctname = ?,cttype = ?,prld = ?,ctsum = ?,paymode = ?,cdDate = ?,prjld = ?,prePay = ?,deposit = ?,ctexecMan = ?,leaderNext = ?,mld = ?,ctdNum = ?,ctdMoney = ?,ctdState = ? where prjld = ?',


	//删除
	userDelete1: "delete from contract where prjld = ?",
	userDelete3: "delete from masterplan where id = ?",



	//wjf
	zongplan: 'insert into masterplan (planname,cmtld,id,leadernext,cdate,mname,useloc,mnum) values (?,?,?,?,?,?,?,?)',
	zongserch: 'select * from masterplan where id = ?',
	zonggai: 'update masterplan set planname=?,cmtld=?,leadernext=?,cdate=?,mname=?,useloc=?,mnum=? where id=?',
	find: 'select planname,cmtld,leadernext,cdate,mname,useloc,mnum from masterplan where id = ?'
}
module.exports = sqlConfig

// let sqlConfig = {
// 	userInsert:'insert into contract (userid,ctname,cttype,prld,ctsum,paymode,cdDate,prjld,prePay,deposit,ctexecMan,leaderNext,mld,ctdNum,ctdMoney,ctdState) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
// 	userSearch:'select * from contract where userid = ?'
// }
// module.exports = sqlConfig