var a_sql = {
    chaxun:"select * from demandplanning where name = ?",
    tianjia:"insert into demandplanning (mrName,id,cmtMan,execMan,cmtDate,comeDate,mmid,useloc,mnum,mprice,ifover,msum,provstate) values (?,?,?,?,?,?,?,?,?,?,?,?,?)",
    xuigai:"update demandplanning set mrName = ?,cmtMan = ?,execMan = ?,cmtDate = ?,comeDate = ?,mmid = ?,useloc = ?,mnum = ?,mprice = ?,ifover = ?,msum = ? where id=?",
    chaxunID: "select * from demandplanning where id = ?",

    
	userDelete2: "delete from demandplanning where id = ?",
}
module.exports = a_sql;