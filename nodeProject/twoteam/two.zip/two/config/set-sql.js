//sql语句
let sqlConfig = {
    // userSearch: 'select * from user where username = ?',  //根据用户名查找
    // userInsert: 'insert into user (username, password, phone, email) values (?, ?, ?, ?)',  //插入
    // userSearch_id: 'select * from user where id = ?', //根据id查找
    // userUpdate: 'update user set username = ?, password = ?, phone = ?, email = ? where id = ?', //修改
    // userDelete: 'delete from user where id = ?',  //根据id删除



    userRegSearch: "select * from user where username = ?",//查找用户
    userReg: "insert into user (username, password, email, phone) values (?, ?, ?, ?)",//注册用户
    
    userSearch: "select * from settlement where ctid = ?", //根据ctid查找
    userSearchID: "select * from settlement where ID = ?", //根据id查找
    userInsert: "insert into settlement (id, prld, ctid) values (?, ?, ?)",  //插入
    userUpdate: "update settlement set prld = ?, ctid = ? where ID = ?", //根据id修改
    userDelete: "delete from settlement where ID = ?", //根据id删除

    masterSearchID: "select * from masterPlan where ID = ?",//总计划查找ID
}
module.exports = sqlConfig;