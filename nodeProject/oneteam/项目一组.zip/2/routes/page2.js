var express = require('express');
var router2 = express.Router();
var db2 = require("../config/db2.js");
var cbfile2 = require("../cbfile/cb2.js")

router2.post("/entering",cbfile2.Entering)
router2.get("/find",cbfile2.Find)
router2.get("/update",cbfile2.update)
router2.post("/delete",cbfile2.delete)

module.exports = router2;