var express = require('express');
var router = express.Router();
var db = require("../config/db2.js");
var cbfile = require("../cbfile/cb1.js")
console.log(cbfile);
// 注册
router.post("/register", cbfile.userRegister);
// 登录
router.post("/login", cbfile.userLogin);


// 材料管理


// 查询数据
router.get("/find", cbfile.userFindAllNumber);

// 修改数据到数据库
router.post("/amend", cbfile.userAmend);

module.exports = router;