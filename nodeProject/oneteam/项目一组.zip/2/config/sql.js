let sc = {
    userInsert:`insert into inventor(username,password,email,phone) values(?,?,?,?)`,
    userSearch:`select * from inventor where username = ?`,
    wdSearch:`select * from inventor where mmidName = ?`,
    wdInsert:`insert into inventor (mmidName,mnum) values (?,?)`,
    add:'insert into inventor (mmidName,mnum) values (?,?)',
    wdDelete:`delete from inventor where id = ?`,
    wdId:`select * from inventor where id = ?`,
    wdNext:`update inventor set mmidName=?,mnum=? where id = ?`,
    wdPname:`select mmidName,mnum from inventor where mmidName = ?`
}
module.exports = sc