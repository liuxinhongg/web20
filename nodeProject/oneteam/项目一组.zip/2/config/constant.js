module.exports={
	// 加密需要密钥，我们定义一个密钥
	PWD_SALT:'simple_code',
	// 密钥自己定义
	PRIVATE_KEY:'liu_xinhong',
	// 设置token过期时间,时间是按秒算的 设置一天过期
	EXPIRESD:60*60*24
}