let sc = {
	userInsert:'insert into delivery (prjid,inputid,teamid,iptDate,filepaths,state,mmid,mloc,mnum,repoid) values (?,?,?,?,?,?,?,?,?,?)',
	find:'select * from delivery',
	xiu:'select * from delivery where prjid=?',
	next:'update delivery set inputid=?, teamid=?, iptDate=?, filepaths=?, state=?, mmid=?, mloc=?, mnum=?, repoid=? where prjid=?',
	delsql:'delete from delivery where prjid=?'
}
module.exports = sc