const { text } = require("express");
// const { userAdd } = require("../cbfile/cb1.js");

let sqlConfig = {
	userInsert: 'insert into admission (username,password,email,phone) values (?,?,?,?)',
	userSearch: 'select * from admission where username = ?',


	// 材料管理
	// 查询全部数据
	userFindAllNumber: 'select * from admission',

	//修改数据到数据库
	userAmend: 'update admission set vno=?,verMan=?,prold=?,phone=?,mCond=?,ifacpt=?,mmind=?,mnum=?,ifsave=?,repold=?,ranver=?,fliepathsmlist=? where verMan = ?',
	// userAmend: 'up into admission (vno, verMan, prold, phone,mConld,aprlistld,ifacpt,mmind,mnum,ifsave,repold,ranver,fliepathsmlist) text (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)' 
}
module.exports = sqlConfig;