let sql = require("../config/sql2.js")
let db = require("../config/db2.js");
// 登录生成token
const jswt = require("jsonwebtoken")

class Bfile {
	// 增加项目
	Entering(req,res,next){
		console.log(req.body)
		var prjid = req.body.prjid;
		var inputid = req.body.inputid;
		var teamid = req.body.teamid;
		var iptDate = req.body.iptDate;
		var filepaths = req.body.filepaths;
		var state = req.body.state;
		var mmid = req.body.mmid;
		var mloc = req.body.mloc;
		var mnum = req.body.mnum;
		var repoid = req.body.repoid;
		db.query(sql.userInsert, [prjid, inputid, teamid, iptDate, filepaths, state, mmid, mloc, mnum, repoid],
			function(result) {
				res.send({
					code: 0,
					message: '录入成功~'
				})
			})
		
	}
	
	// 查询全部
	Find(req,res,next){
		db.query(sql.find,function(err,result){
			if(err){
				console.log(err.message);
				return
			} else{
				res.send({
					message: result
				})
			}
			console.log(result)
		})
	}

	// 修改项目信息
	update(req,res,next){
		var prjid = req.query.prjid;
		var inputid = req.query.inputid;
		var teamid = req.query.teamid;
		var iptDate = req.query.iptDate;
		var filepaths = req.query.filepaths;
		var state = req.query.state;
		var mmid = req.query.mmid;
		var mloc = req.query.mloc;
		var mnum = req.query.mnum;
		var repoid = req.query.repoid;
		if (prjid == "" || prjid == undefined) {
            res.send({ code: -1, message: "项目不能为空" })
        }
		db.query(sql.xiu,[prjid],function(result){
			if(result.length){
				db.query(sql.next,[inputid,teamid,iptDate,filepaths,state,mmid,mloc,mnum,repoid,prjid],function(result) {
					res.send({code:0,message:"修改成功"})
				})
			} else {
                res.send({ message: "不存在", code: 1 })
            }
		})
	}

	// 删除项目信息
	delete(req, res, next) {
        var prjid = req.body.prjid;
        db.query(sql.delsql, [prjid], function (result) {
            res.send({ code: 1, message: "删除成功!" })
        })
    }
	
}


module.exports = new Bfile()