let sqlconfig = require("../config/sql3.js");
let db = require("../config/db2.js");
// 登录生成token
// const jswt = require("jsonwebtoken")
// const { md5 } = require("../config/method.js");
// const { key, PRIVATE_KEY, EXPIRESD } = require("../config/constant.js")
class Bfile {
    userRegister(req, res, next) {
        var user = req.body.username;
        var pass = req.body.password;
        var email = req.body.email;
        var phone = req.body.phone;
        if ((user == "" || user == undefined) && (pass == "" || pass == undefined)) {
            res.send({
                code: -1,
                message: "用户名不能为空"
            })
        } else {
            db.query(sqlconfig.userSearch, [user], function (result) {
                if (result.length) {
                    res.send({
                        message: "该用户已注册",
                        code: 1
                    })
                } else {
                    pass = md5(`${pass}${pass}`);
                    db.query(sqlconfig.userInsert, [user, pass, email, phone], function (result) {
                        res.send({
                            message: '注册成功~',
                            code: 0
                        })
                    })
                }
            })
        }
    }
    userLogin(req, res, next) {
        var user = req.body.username;
        var pass = req.body.password;
        if (!user && !pass) {
            res.send({
                code: -1,
                message: "用户名或密码不能为空"
            })
        } else {
            db.query(sqlconfig.userSearch, [user], function (result) {
                if (result.length) {
                    pass = md5(`${pass}${key}`);
                    // 首先要确保用户存在,这样我们就可以生成一个token,
                    if (result[0].password === pass) {
                        // 生成token jswt.sign({user},密钥，过期时间)
                        let token = jswt.sign({
                            user
                        }, PRIVATE_KEY, {
                            expiresIn: EXPIRESD
                        });
                        res.send({
                            code: 0,
                            message: "登录成功",
                            token: token
                        })
                    } else {
                        res.send({
                            code: 1,
                            message: "密码错误"
                        })
                    }
                } else {
                    res.send({
                        code: 2,
                        message: "用户名不存在，请先注册"
                    })
                }
            })
        }
    }
    userFindAllNumber(req, res, next) {
        db.query(sqlconfig.userFindAllNumber, function (err, result) {
            if (err) {
                console.log(err.message);
                return
            } else {
                res.send({
                    message: result
                })
            }
        })
    }

    userAmend(req, res, next) {
        var vno = req.body.vno;
        var verMan = req.body.verMan;
        var prold = req.body.prold;
        var mConld = req.body.mConld;
        var aprlistld = req.body.aprlistld;
        var ifacpt = req.body.ifacpt;
        var mmind = req.body.mmind;
        var mnum = req.body.mnum;
        var ifsave = req.body.ifsave;
        var repold = req.body.repold;
        var rmanver = req.body.rmanver;
        var fliepathsmlist = req.body.fliepathsmlist;
        if (verMan == "" || verMan == undefined) {
            res.send({
                code: -1,
                message: "请正确输入验收人员姓名"
            })
        } else {
            db.query(sqlconfig.userAmend, [mConld], function (result) {
                if (result.length) {
                    res.send({
                        message: "正在修改",
                        code: 1
                    })
                } else {
                    db.query(sqlconfig.userAmend, [vno, verMan, prold, phone,mConld,aprlistld,ifacpt,mmind,mnum,ifsave,repold,ranver,fliepathsmlist], function (result) {
                        res.send({
                            message: '修改成功~',
                            code: 0
                        })
                    })
                }
            })
        }
    }
}
module.exports = new Bfile()