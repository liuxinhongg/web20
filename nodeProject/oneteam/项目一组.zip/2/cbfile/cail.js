let sql = require("../config/sql.js");
let db = require("../config/db.js")
// const jswt = require("jsonwebtoken")

class Cl {
    add(req, res, next) {
        res.send({ code: -1, message: "用户名不能为空" })
        // console.log(res);
        var mmidName = req.body.mmidName;
        var mnum = req.body.mnum;
        if (mmidName == "" || mmidName == undefined) {
            res.send({ code: -1, message: "用户名不能为空" })
        } else {
            db.query(sql.wdSearch, [mmidName], function (result) {
                if (result.length) {
                    res.send({ message: "该用户已存在", code: 1 })
                } else {
                    db.query(sql.wdInsert, [mmidName, mnum], function (result) {
                        res.send({ code: 0, message: '添加成功~' })
                    })
                }
            })
        }
    }
    delete(req, res, next) {
        var id = req.body.id;
        db.query(sql.wdDelete, [id], function (result) {
            res.send({ code: 1, message: "删除成功!" })
        })
    }
    update(req, res, next) {
        var id = req.query.id;
        var mmidName = req.query.mmidName;
        var mnum = req.query.mnum;
        if (pname == "" || pname == undefined) {
            res.send({ code: -1, message: "用户名不能为空" })
        }
        db.query(sql.wdId, [id], function (result) {
            if (result.length) {
                db.query(sql.wdNext, [mmidName, mnum, id], function (result) {
                    res.send({ code: 0, message: "成功" });
                })
            } else {
                res.send({ message: "不存在", code: 1 })
            }
        })
    }
    userinfo(req, res, next) {
        var mmidName = req.query.mmidName;
        if (pname == "" || pname == undefined) {
          res.send({ code: -1, message: "不能空" })
        }
        db.query(sql.wdPname, [mmidName], function (result) {
          if (result.length) {
            res.send({ data: result[0], code: "成功", code: 0 })
          } else {
            res.send({ data: "不存在", code: 1 })
          }
        })
    }
}

module.exports = new Cl()