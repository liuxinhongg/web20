var express = require("express");
var router = express.Router();
let cc = require("../cbfile/cc.js");

router.post("/add",cc.tj);
router.post("/delete",cc.sc);
router.post("/cz",cc.cz);
router.post("/xg",cc.xg)

module.exports = router;