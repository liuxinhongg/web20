var express = require('express');
var router = express.Router();
var db = require("../config/db.js");
var cail = require("../cbfile/cail.js")

router.post("/add",cail.add)
// router.post("/delete",cail.delete)
router.get("/update",cail.update)
router.get("/userinfo",cail.userinfo)

//增
// router.post("/add", function (req, res, next) {
//     var pname = req.body.pname;
//     var parea = req.body.parea;
//     var pcotype = req.body.pcotype;
//     var ptype = req.body.ptype;
//     var pprof = req.body.pprof;
//     var paddr = req.body.paddr;
//     var leader = req.body.leader;
//     var personid = req.body.personid;
//     var telno = req.body.telno;
//     var coid = req.body.coid;
//     var bankname = req.body.bankname;
//     var bankcode = req.body.bankcode;
//     if (pname == "" || pname == undefined) {
//         res.send({ code: -1, message: "用户名不能为空" })
//     } else {
//         db.query("select * from wd where pname = ?", [pname], function (result) {
//             if (result.length) {
//                 res.send({ message: "该用户已存在", code: 1 })
//             } else {
//                 db.query("insert into wd (pname,parea,pcotype,ptype,pprof,paddr,leader,personid,telno,coid,bankname,bankcode) values (?,?,?,?,?,?,?,?,?,?,?,?)", [pname, parea, pcotype, ptype, pprof, paddr, leader, personid, telno, coid, bankname, bankcode], function (result) {
//                     res.send({ code: 0, message: '添加成功~' })
//                 })
//             }
//         })
//     }
// })


//删
// router.post("/delete", function (req, res, next) {
//     var id = req.body.id;
//     db.query("delete from wd where id = ?", [id], function (result) {
//         res.send({ code: 1, message: "删除成功!" })
//     })
// })


//改
// router.get("/update", function (req, res, next) {
//     var id = req.query.id;
//     var pname = req.query.pname;
//     var parea = req.query.parea;
//     var pcotype = req.query.pcotype;
//     var ptype = req.query.ptype;
//     var pprof = req.query.pprof;
//     var paddr = req.query.paddr;
//     var leader = req.query.leader;
//     var personid = req.query.personid;
//     var telno = req.query.telno;
//     var coid = req.query.coid;
//     var bankname = req.query.bankname;
//     var bankcode = req.query.bankcode;
//     if (pname == "" || pname == undefined) {
//         res.send({ code: -1, message: "用户名不能为空" })
//     }
//     db.query("select * from wd where id = ?", [id], function (result) {
//         if (result.length) {
//             db.query("update wd set pname=?,parea=?, pcotype=?, ptype=?, pprof=?, paddr=?, leader=?, personid=?, telno=?, coid=?, bankname=?, bankcode=? where id = ?", [pname, parea, pcotype, ptype, pprof, paddr, leader, personid, telno, coid, bankname, bankcode, id], function (result) {
//                 res.send({ code: 0, message: "成功" });
//             })
//         } else {
//             res.send({ message: "不存在", code: 1 })
//         }
//     })
// })

//查找
// router.get("/userinfo", function (req, res, next) {
//     var pname = req.query.pname;
//     if (pname == "" || pname == undefined) {
//       res.send({ code: -1, message: "不能空" })
//     }
//     db.query("select pname,parea,pcotype,ptype,pprof,paddr,leader,personid,telno,coid,bankname,bankcode from wd where pname = ?", [pname], function (result) {
//       if (result.length) {
//         res.send({ data: result[0], code: "成功", code: 0 })
//       } else {
//         res.send({ data: "不存在", code: 1 })
//       }
//     })
//   })


  module.exports = router;
