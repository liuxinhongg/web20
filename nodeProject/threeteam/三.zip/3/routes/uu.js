var express = require("express");
var router = express.Router();
var cail = require("../cbfile/aa.js")

router.post("/add",cail.add)
router.post("/delete",cail.delete)
router.get("/update",cail.update)
router.get("/userinfo",cail.userinfo)
module.exports = router;