var express = require("express");
var router = express.Router()
let db = require('../config/db.js')
var cb = require("../cbfile/cb.js")

router.post("/register", cb.register)
router.post("/login",cb.login)
module.exports = router