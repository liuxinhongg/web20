var express = require('express');
var router = express.Router();
var db = require("../config/db.js");

/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

router.post("/register", function (req, res, next) {
  var user = req.body.username;
  var pass = req.body.password;
  var email = req.body.email;
  var phone = req.body.phone;
  if (user == "" || user == undefined) {
    res.send({ code: -1, message: "用户名不能为空" })
  } else {
    db.query("select * from user where username = ?", [user], function (result) {
      if (result.length) {
        res.send({ message: "该用户已注册", code: 1 })
      } else {
        db.query("insert into user (username,password,email,phone) values (?,?,?,?)", [user, pass, email, phone], function (result) {
          res.send({ code: 0, message: '注册成功~' })
        })
      }
    })
  }
})

router.post("/login", function (req, res, next) {
  var user = req.body.username;
  var pass = req.body.password;
  if (user == "" || user == undefined) {
    res.send({ code: -1, message: "用户名不能为空" })
  } else {
    db.query("select * from user where username = ?", [user], function (result) {
      if (result.length) {
        if (pass === result[0].password) {
          console.log(result);
          res.send({ code: 1, message: "成功", "密码": result[0].password });
        } else {
          res.send({ code: -1, message: "错误" })
        }
      } else {
        res.send({ code: -2, message: "不存在" });
      }
    })
  }
})

router.get("/userinfo", function (req, res, next) {
  var user = req.query.username;
  if (user == "" || user == undefined) {
    res.send({ code: -1, message: "不能空" })
  }
  db.query("select username, email, phone from user where username = ?", [user], function (result) {
    if (result.length) {
      res.send({ data: result[0], code: "成功", code: 0 })
    } else {
      res.send({ data: "不存在", code: 1 })
    }
  })
})



router.get("/update", function (req, res, next) {
  var id = req.query.id;
  var user = req.query.username;
  var pass = req.query.password;
  var email = req.query.email;
  var phone = req.query.phone;
  if (user == "" || user == undefined) {
    res.send({ code: -1, message: "用户名不能为空" })
  }
  db.query("select * from user where id = ?", [id], function (result) {
    if (result.length) {
      db.query("update user set username=?,password=?, email=?, phone=? where id = ?", [user, pass, email, phone, id], function (result) {
        res.send({ code: 0, message: "成功" });
      })
    } else {
      res.send({ message: "不存在", code: 1 })
    }
  })
})

module.exports = router;