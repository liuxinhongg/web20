let sql = require("../config/bb");
let db1 = require("../config/db.js");

class cBfile {
    tj(req, res, next) {
        var u = {
            mcode: req.body.mcode,
            mname: req.body.mname,
            mtype: req.body.mtype,
            munit: req.body.munit,
            filepaths: req.body.filepaths,
            remark: req.body.remark
        }
        if ((u.mcode == "" || u.mcode == undefined) && (u.mname == "" || u.mname == undefined)) {
            res.send({
                msg: "用户名或密码不能为空",
                code: -1
            })
        } else {
            var searchSql = sql.mcode;
            db1.query(searchSql, [u.mcode], function (result, fileds) {
                if (result.length) {
                    res.send({
                        msg: "该用户已注册",
                        code: 1
                    })
                } else {
                    var addSql = sql.daa;
                    var addSqlQuery = [u.mcode, u.mname, u.mtype, u.munit, u.filepaths, u.remark];
                    db1.query(addSql, addSqlQuery, function (result) {
                        res.send({
                            msg: "注册成功！",
                            code: 0,
                            data: result
                        })
                    })
                }
            })
        }
    }
    sc(req, res, next) {
        var id = req.body.id;
        db1.query(sql.dl, [id], function (result) {
            res.send({
                code: 0,
                msg: "删除成功"
            })
        })
    }
    cz(req, res, next) {
        var mname = req.body.mname;
        if (mname == "" || mname == undefined) {
            res.send({
                code: -1,
                message: "不能为空"
            })
        }
        db1.query(sql.mname, [mname], function (result) {
            if (result.length) {
                res.send({ data: result[0], code: "成功", code: 0 })
            } else {
                res.send({ data: "不存在", code: 1 })
            }
        })
    }
    xg(req, res, next) {
        var id = req.body.id;
        var mcode = req.body.mcode;
        var mname = req.body.mname;
        var mtype = req.body.mtype;
        var munit = req.body.munit;
        var filepaths = req.body.filepaths;
        var remark = req.body.remark
        if (mcode == "" || mcode == undefined) {
            res.send({ code: -1, message: "用户名不能为空" })
        }
        db1.query(sql.Id, [id], function (result) {
            console.log(result)
            if (result.length) {
                db1.query(sql.up, [mcode, mname, mtype, munit, filepaths, remark, id], function (result) {
                    res.send({ code: 0, message: "成功" });
                })
            } else {
                res.send({ message: "不存在", code: 1 })
            }
        })
    }
}
module.exports = new cBfile()