let sql = require("../config/sql.js");
let db = require("../config/db.js")
const jswt = require("jsonwebtoken")

class cl {
    add(req, res, next) {
        var pname = req.body.pname;
        var parea = req.body.parea;
        var pcotype = req.body.pcotype;
        var ptype = req.body.ptype;
        var pprof = req.body.pprof;
        var paddr = req.body.paddr;
        var leader = req.body.leader;
        var personid = req.body.personid;
        var telno = req.body.telno;
        var coid = req.body.coid;
        var bankname = req.body.bankname;
        var bankcode = req.body.bankcode;
        if (pname == "" || pname == undefined) {
            res.send({ code: -1, message: "用户名不能为空" })
        } else {
            db.query(sql.wdSearch, [pname], function (result) {
                if (result.length) {
                    res.send({ message: "该用户已存在", code: 1 })
                } else {
                    db.query(sql.wdInsert, [pname, parea, pcotype, ptype, pprof, paddr, leader, personid, telno, coid, bankname, bankcode], function (result) {
                        res.send({ code: 0, message: '添加成功~' })
                    })
                }
            })
        }
    }
    delete(req, res, next) {
        var id = req.body.id;
        db.query(sql.wdDelete, [id], function (result) {
            res.send({ code: 1, message: "删除成功!" })
        })
    }
    update(req, res, next) {
        var id = req.query.id;
        var pname = req.query.pname;
        var parea = req.query.parea;
        var pcotype = req.query.pcotype;
        var ptype = req.query.ptype;
        var pprof = req.query.pprof;
        var paddr = req.query.paddr;
        var leader = req.query.leader;
        var personid = req.query.personid;
        var telno = req.query.telno;
        var coid = req.query.coid;
        var bankname = req.query.bankname;
        var bankcode = req.query.bankcode;
        if (pname == "" || pname == undefined) {
            res.send({ code: -1, message: "用户名不能为空" })
        }
        db.query(sql.wdId, [id], function (result) {
            if (result.length) {
                db.query(sql.wdNext, [pname, parea, pcotype, ptype, pprof, paddr, leader, personid, telno, coid, bankname, bankcode, id], function (result) {
                    res.send({ code: 0, message: "成功" });
                })
            } else {
                res.send({ message: "不存在", code: 1 })
            }
        })
    }
    userinfo(req, res, next) {
        var pname = req.query.pname;
        if (pname == "" || pname == undefined) {
          res.send({ code: -1, message: "不能空" })
        }
        db.query(sql.wdPname, [pname], function (result) {
          if (result.length) {
            res.send({ data: result[0], code: "成功", code: 0 })
          } else {
            res.send({ data: "不存在", code: 1 })
          }
        })
    }
}

module.exports = new cl()