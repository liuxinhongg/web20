let sql = require("../config/shuju.js");
let db = require("../config/db.js");

class Uu {
    add(req, res, next) {
        var storeMan = req.body.storeMan;
        var storeName = req.body.storeName;
        var storeLoc = req.body.storeLoc;
        var remark = req.body.remark;
        if (storeMan == "" || storeMan == undefined) {
            res.send({ code: -1, message: "用户名不能为空" })
        } else {
            db.query(sql.wdSearch, [storeMan], function (result) {
                if (result.length) {
                    res.send({ message: "该用户已存在", code: 1 })
                } else {
                    db.query(sql.wdInsert, [storeMan, storeName, storeLoc, remark], function (result) {
                        res.send({ code: 0, message: '添加成功~' })
                    })
                }
            })
        }
    }
    
    delete(req, res, next) {
        var id = req.body.id;
        db.query(sql.wdIdd, [id], function (result) {
            res.send({ code: 1, message: "删除成功!" })
        })
    }
    
    //改
    update(req, res, next) {
        var id = req.query.id;
        var storeMan = req.query.storeMan;
        var storeName = req.query.storeName;
        var storeLoc = req.query.storeLoc;
        var remark = req.query.remark;
        if (storeMan == "" || storeMan == undefined) {
            res.send({ code: -1, message: "用户名不能为空" })
        }
        db.query(sql.wdId, [id], function (result) {
            if (result.length) {
                db.query(sql.wdNext, [storeMan, storeName, storeLoc, remark,id], function (result) {
                    res.send({ code: 0, message: "成功" });
                })
            } else {
                res.send({ message: "不存在", code: 1 })
            }
        })
    }
    
    
    //查找
    userinfo(req, res, next) {
        var storeName = req.query.storeName;
        console.log(storeName);
        if (storeName == "" || storeName == undefined) {
          res.send({ code: -1, message: "不能空" })
        }
        db.query(sql.wdPname, [storeName], function (result) {
          if (result.length) {
            res.send({ data: result[0], code: "成功", code: 0 })
          } else {
            res.send({ data: "不存在", code: 1 })
          }
        })
      }
}
module.exports = new Uu()