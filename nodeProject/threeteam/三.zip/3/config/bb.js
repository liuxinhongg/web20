let sqlConfig = {
    mcode:'select * from basics where mcode = ?',
    daa:'insert into basics(mcode,mname,mtype,munit,filepaths,remark) values(?,?,?,?,?,?)',
    dl:'delete from basics where id = ?',
    mname:'select * from basics where mname = ?',
    Id:'select * from basics where id = ?',
    up:'update basics set mcode=?,mname=?, mtype=?, munit=?, filepaths=?, remark=? where id = ?'
}
module.exports = sqlConfig;