let sc = {
    userInsert:`insert into user(username,password,email,phone) values(?,?,?,?)`,
    userSearch:`select * from user where username = ?`,
    wdSearch:`select * from wd where pname = ?`,
    wdInsert:`insert into wd (pname,parea,pcotype,ptype,pprof,paddr,leader,personid,telno,coid,bankname,bankcode) values (?,?,?,?,?,?,?,?,?,?,?,?)`,
    wdDelete:`delete from wd where id = ?`,
    wdId:`select * from wd where id = ?`,
    wdNext:`update wd set pname=?,parea=?, pcotype=?, ptype=?, pprof=?, paddr=?, leader=?, personid=?, telno=?, coid=?, bankname=?, bankcode=? where id = ?`,
    wdPname:`select pname,parea,pcotype,ptype,pprof,paddr,leader,personid,telno,coid,bankname,bankcode from wd where pname = ?`
}
module.exports = sc