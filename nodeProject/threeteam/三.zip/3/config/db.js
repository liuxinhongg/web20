var mysql = require("mysql");
var pool = mysql.createPool({
	host: "123.57.225.101",
	user: "root",
	password: "Wdq10733!",
	port: "3306",
	database: "Materialsettings"
})
exports.query = function (sql, arr, callback) {
	// 建立连接
	pool.getConnection(function (err, connection) {
		if (err) {
			throw err;
			return;
		}
		connection.query(sql, arr, function (error, result) {
			connection.release();
			if (error) throw error;
			callback && callback(result)
		})
	})
}