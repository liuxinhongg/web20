let sqlConfig = {
    userInsert:`insert into user(username,password,email,phone) values(?,?,?,?)`,
    userSearch:`select * from user where username = ?`,
    wdSearch:`select * from w2 where storeMan = ?`,
    wdIdd:`delete from w2 where id =?`,
    wdInsert:`insert into w2 (storeMan,storeName,storeLoc,remark) values (?,?,?,?)`,
    wdId:`select * from w2 where id = ?`,
    wdNext:`update w2 set storeMan=?,storeName=?, storeLoc=?, remark=? where id = ?`,
    wdPname:`select * from w2 where storeName = ?`
}
module.exports = sqlConfig;